import React, { useState, useEffect, Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from 'sonner';
import { AnimatePresence, motion } from 'framer-motion';
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';
import ProtectedRoute from './components/ProtectedRoute';
import SupportChatWidget from './components/SupportChatWidget';
import useStore from './store/useStore';

const Login = lazy(() => import('./components/Login'));
const DashboardOverview = lazy(() => import('./components/DashboardOverview'));
const PolicyList = lazy(() => import('./components/PolicyList'));
const ClaimsTracker = lazy(() => import('./components/ClaimsTracker'));
const PaymentHistory = lazy(() => import('./components/PaymentHistory'));
const PremiumCalculator = lazy(() => import('./components/PremiumCalculator'));
const DocumentUpload = lazy(() => import('./components/DocumentUpload'));
const UserProfile = lazy(() => import('./components/UserProfile'));
const AdminPanel = lazy(() => import('./components/AdminPanel'));

const queryClient = new QueryClient();

const PageLoader = () => (
  <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%', width: '100%', minHeight: '300px' }}>
    <div style={{ width: '40px', height: '40px', border: '4px solid var(--border-color)', borderTopColor: 'var(--accent-primary)', borderRadius: '50%', animation: 'spin 1s linear infinite' }}></div>
    <style>{`@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }`}</style>
  </div>
);

const AnimatedRoute = ({ children }) => (
  <motion.div initial={{ opacity: 0, y: 15 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -15 }} transition={{ duration: 0.3, ease: 'easeOut' }}>
    {children}
  </motion.div>
);

const AppRoutes = ({ isAuthenticated }) => {
  const location = useLocation();
  return (
    <div className={isAuthenticated ? "content-area" : ""}>
      {isAuthenticated && (
        <div className="reminder-banner">
          <div><strong>Action Required:</strong> Your Health Insurance renewal is due in 3 days.</div>
          <button className="btn btn-outline" style={{ borderColor: 'rgba(255,255,255,0.4)', color: 'white' }}>Snooze</button>
        </div>
      )}
      <Suspense fallback={<PageLoader />}>
        <AnimatePresence mode="wait">
          <Routes location={location} key={location.pathname}>
            <Route path="/login" element={!isAuthenticated ? <AnimatedRoute><Login /></AnimatedRoute> : <Navigate to="/dashboard" replace />} />
            <Route path="/" element={<Navigate to="/dashboard" replace />} />
            <Route path="/dashboard" element={<ProtectedRoute><AnimatedRoute><DashboardOverview /></AnimatedRoute></ProtectedRoute>} />
            <Route path="/policies" element={<ProtectedRoute><AnimatedRoute><PolicyList /></AnimatedRoute></ProtectedRoute>} />
            <Route path="/claims" element={<ProtectedRoute><AnimatedRoute><ClaimsTracker /></AnimatedRoute></ProtectedRoute>} />
            <Route path="/payments" element={<ProtectedRoute><AnimatedRoute><PaymentHistory /></AnimatedRoute></ProtectedRoute>} />
            <Route path="/calculator" element={<ProtectedRoute><AnimatedRoute><PremiumCalculator /></AnimatedRoute></ProtectedRoute>} />
            <Route path="/documents" element={<ProtectedRoute><AnimatedRoute><DocumentUpload /></AnimatedRoute></ProtectedRoute>} />
            <Route path="/profile" element={<ProtectedRoute><AnimatedRoute><UserProfile /></AnimatedRoute></ProtectedRoute>} />
            <Route path="/admin" element={<ProtectedRoute><AnimatedRoute><AdminPanel /></AnimatedRoute></ProtectedRoute>} />
          </Routes>
        </AnimatePresence>
      </Suspense>
    </div>
  );
};

function App() {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const { isDarkMode, isAuthenticated } = useStore();

  useEffect(() => {
    if (isDarkMode) document.body.classList.add('dark');
    else document.body.classList.remove('dark');
  }, [isDarkMode]);

  const toggleSidebar = () => setIsSidebarCollapsed(!isSidebarCollapsed);

  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <div className={`app-container ${isDarkMode ? 'dark' : ''}`}>
          <Toaster theme={isDarkMode ? 'dark' : 'light'} position="bottom-right" />
          {isAuthenticated && <Sidebar isCollapsed={isSidebarCollapsed} toggleSidebar={toggleSidebar} />}
          <main className="main-content">
            {isAuthenticated && <Navbar toggleSidebar={toggleSidebar} />}
            <AppRoutes isAuthenticated={isAuthenticated} />
            {isAuthenticated && <SupportChatWidget />}
          </main>
        </div>
      </Router>
    </QueryClientProvider>
  );
}

export default App;
