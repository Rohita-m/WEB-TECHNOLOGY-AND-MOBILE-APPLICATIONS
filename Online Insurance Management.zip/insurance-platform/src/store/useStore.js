import { create } from 'zustand';

const useStore = create((set) => ({
  user: null,
  isAuthenticated: false,
  isDarkMode: localStorage.getItem('theme') === 'dark',
  
  // Actions
  login: (userData) => {
    localStorage.setItem('token', 'mock-jwt-token');
    set({ user: userData, isAuthenticated: true });
  },
  
  logout: () => {
    localStorage.removeItem('token');
    set({ user: null, isAuthenticated: false });
  },
  
  updateUser: (newDetails) => set((state) => ({
    user: { ...state.user, ...newDetails }
  })),

  toggleTheme: () => set((state) => {
    const newTheme = !state.isDarkMode;
    if (newTheme) {
      document.body.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.body.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
    return { isDarkMode: newTheme };
  })
}));

export default useStore;
