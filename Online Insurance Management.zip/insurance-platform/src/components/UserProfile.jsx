import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';
import { User, Mail, Phone, MapPin, Shield, Edit2, Save } from 'lucide-react';
import useStore from '../store/useStore';

const profileSchema = z.object({
  name: z.string().min(2, 'Name is required'),
  email: z.string().email('Invalid email format'),
  phone: z.string().min(10, 'Valid phone number required'),
  address: z.string().min(10, 'Address is too short'),
  nomineeName: z.string().min(2, 'Nominee name required'),
  nomineeRelation: z.string().min(2, 'Relationship required')
});

const UserProfile = () => {
  const { user, updateUser } = useStore();
  const [isEditing, setIsEditing] = useState(false);

  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: user?.name || '', email: user?.email || '', phone: user?.phone || '', 
      address: user?.address || '', nomineeName: user?.nomineeName || '', nomineeRelation: user?.nomineeRelation || ''
    }
  });

  const onSubmit = (data) => {
    updateUser(data);
    toast.success('Profile Updated', { description: 'Your information has been saved successfully.' });
    setIsEditing(false);
  };

  return (
    <div style={{ maxWidth: '850px', margin: '0 auto' }}>
      <form onSubmit={handleSubmit(onSubmit)}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2.5rem' }}>
          <h2>Profile Settings</h2>
          {isEditing ? <button type="submit" className="btn btn-primary"><Save size={18} /> Save</button> : <button type="button" className="btn btn-outline" onClick={() => setIsEditing(true)}><Edit2 size={18} /> Edit</button>}
        </div>

        <div className="card" style={{ marginBottom: '2.5rem', display: 'flex', alignItems: 'center', gap: '2.5rem', padding: '2.5rem' }}>
          <img src={`https://api.dicebear.com/7.x/lorelei/svg?seed=${user?.name || 'User'}`} alt="Profile" style={{ width: '120px', height: '120px', borderRadius: '50%', background: 'var(--accent-secondary)', border: '4px solid var(--accent-primary)', padding: '0.5rem' }} />
          <div style={{ flex: 1 }}>
            <h2 style={{ marginBottom: '0.5rem' }}>{user?.name}</h2>
            <p className="secondary-text" style={{ fontSize: '1rem' }}>{user?.role} since 2022</p>
            <div style={{ marginTop: '1.5rem' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.8rem' }}><span className="secondary-text">Profile Completion</span><span style={{ fontWeight: 700 }}>85%</span></div>
              <div className="progress-container"><div className="progress-bar" style={{ width: '85%' }}></div></div>
            </div>
          </div>
        </div>

        <div className="card" style={{ padding: '2.5rem' }}>
          <h3 style={{ marginBottom: '2rem', display: 'flex', alignItems: 'center', gap: '0.75rem' }}><User size={22} color="var(--accent-primary)" /> Personal Information</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
            <div className="form-group"><label className="form-label">Name</label><div style={{ position: 'relative' }}><User size={18} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }} /><input type="text" className="form-input" style={{ paddingLeft: '2.75rem', borderColor: errors.name ? 'var(--status-expired-text)' : '' }} disabled={!isEditing} {...register('name')} /></div>{errors.name && <p style={{ color: 'var(--status-expired-text)', fontSize: '0.8rem', marginTop: '0.25rem' }}>{errors.name.message}</p>}</div>
            <div className="form-group"><label className="form-label">Email</label><div style={{ position: 'relative' }}><Mail size={18} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }} /><input type="email" className="form-input" style={{ paddingLeft: '2.75rem', borderColor: errors.email ? 'var(--status-expired-text)' : '' }} disabled={!isEditing} {...register('email')} /></div>{errors.email && <p style={{ color: 'var(--status-expired-text)', fontSize: '0.8rem', marginTop: '0.25rem' }}>{errors.email.message}</p>}</div>
            <div className="form-group"><label className="form-label">Phone</label><div style={{ position: 'relative' }}><Phone size={18} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }} /><input type="tel" className="form-input" style={{ paddingLeft: '2.75rem', borderColor: errors.phone ? 'var(--status-expired-text)' : '' }} disabled={!isEditing} {...register('phone')} /></div>{errors.phone && <p style={{ color: 'var(--status-expired-text)', fontSize: '0.8rem', marginTop: '0.25rem' }}>{errors.phone.message}</p>}</div>
            <div className="form-group"><label className="form-label">Address</label><div style={{ position: 'relative' }}><MapPin size={18} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }} /><input type="text" className="form-input" style={{ paddingLeft: '2.75rem', borderColor: errors.address ? 'var(--status-expired-text)' : '' }} disabled={!isEditing} {...register('address')} /></div>{errors.address && <p style={{ color: 'var(--status-expired-text)', fontSize: '0.8rem', marginTop: '0.25rem' }}>{errors.address.message}</p>}</div>
          </div>
          <h3 style={{ margin: '3rem 0 2rem', display: 'flex', alignItems: 'center', gap: '0.75rem', paddingTop: '2rem', borderTop: '1px solid var(--border-color)' }}><Shield size={22} color="var(--accent-primary)" /> Nominee Details</h3>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
            <div className="form-group"><label className="form-label">Nominee Name</label><input type="text" className="form-input" disabled={!isEditing} style={{ borderColor: errors.nomineeName ? 'var(--status-expired-text)' : '' }} {...register('nomineeName')} />{errors.nomineeName && <p style={{ color: 'var(--status-expired-text)', fontSize: '0.8rem', marginTop: '0.25rem' }}>{errors.nomineeName.message}</p>}</div>
            <div className="form-group"><label className="form-label">Relationship</label><input type="text" className="form-input" disabled={!isEditing} style={{ borderColor: errors.nomineeRelation ? 'var(--status-expired-text)' : '' }} {...register('nomineeRelation')} />{errors.nomineeRelation && <p style={{ color: 'var(--status-expired-text)', fontSize: '0.8rem', marginTop: '0.25rem' }}>{errors.nomineeRelation.message}</p>}</div>
          </div>
        </div>
      </form>
    </div>
  );
};
export default UserProfile;
