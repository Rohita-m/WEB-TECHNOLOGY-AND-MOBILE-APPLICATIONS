import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { LayoutDashboard, FileText, Activity, CreditCard, Calculator, FolderOpen, User, Settings, LogOut, ChevronLeft, ChevronRight } from 'lucide-react';
import useStore from '../store/useStore';

const Sidebar = ({ isCollapsed, toggleSidebar }) => {
  const logout = useStore((state) => state.logout);
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const navItems = [
    { path: '/dashboard', name: 'Dashboard', icon: <LayoutDashboard size={20} /> },
    { path: '/policies', name: 'My Policies', icon: <FileText size={20} /> },
    { path: '/claims', name: 'Claims', icon: <Activity size={20} /> },
    { path: '/payments', name: 'Payments', icon: <CreditCard size={20} /> },
    { path: '/calculator', name: 'Calculator', icon: <Calculator size={20} /> },
    { path: '/documents', name: 'Documents', icon: <FolderOpen size={20} /> },
    { path: '/admin', name: 'Admin Panel', icon: <Settings size={20} /> },
    { path: '/profile', name: 'Profile', icon: <User size={20} /> },
  ];

  return (
    <aside className={`sidebar ${isCollapsed ? 'collapsed' : ''}`}>
      <div style={{ padding: '1.5rem', display: 'flex', alignItems: 'center', justifyContent: isCollapsed ? 'center' : 'space-between', borderBottom: '1px solid var(--border-color)' }}>
        {!isCollapsed && <h2 style={{ fontSize: '1.5rem', fontFamily: 'Outfit', fontWeight: 800, background: 'var(--accent-gradient)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', marginBottom: 0 }}>SureGuard</h2>}
        <button onClick={toggleSidebar} className="btn btn-outline" style={{ padding: '0.4rem', borderRadius: '50%' }}>
          {isCollapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
        </button>
      </div>

      <nav style={{ padding: '1rem 0', flex: 1, display: 'flex', flexDirection: 'column', gap: '0.5rem', overflowY: 'auto' }}>
        {navItems.map((item) => (
          <NavLink
            key={item.path}
            to={item.path}
            style={({ isActive }) => ({
              display: 'flex', alignItems: 'center', padding: '0.85rem 1.5rem',
              color: isActive ? 'var(--accent-primary)' : 'var(--text-secondary)',
              backgroundColor: isActive ? 'var(--accent-secondary)' : 'transparent',
              textDecoration: 'none', fontWeight: isActive ? 600 : 500,
              borderRight: isActive ? '4px solid var(--accent-primary)' : '4px solid transparent',
              transition: 'all var(--transition-fast)', justifyContent: isCollapsed ? 'center' : 'flex-start'
            })}
          >
            <span style={{ display: 'flex' }}>{item.icon}</span>
            {!isCollapsed && <span style={{ marginLeft: '1rem' }}>{item.name}</span>}
          </NavLink>
        ))}
      </nav>

      <div style={{ padding: '1.5rem' }}>
        <button onClick={handleLogout} className="btn" style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: isCollapsed ? 'center' : 'flex-start', color: 'var(--status-expired-text)', background: 'var(--status-expired-bg)' }}>
          <LogOut size={20} />
          {!isCollapsed && <span style={{ marginLeft: '1rem' }}>Logout</span>}
        </button>
      </div>
    </aside>
  );
};
export default Sidebar;
