import React, { useState } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';

const SupportChatWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [msg, setMsg] = useState('');
  const [chats, setChats] = useState([{ text: 'Hello! How can we help?', isBot: true }]);

  const handleSend = (e) => {
    e.preventDefault(); if (!msg.trim()) return;
    setChats([...chats, { text: msg, isBot: false }]); setMsg('');
    setTimeout(() => setChats(prev => [...prev, { text: 'An agent will be with you shortly.', isBot: true }]), 1000);
  };

  return (
    <div className="support-widget">
      {!isOpen && <div className="support-btn" onClick={() => setIsOpen(true)}><MessageCircle size={28} /></div>}
      {isOpen && (
        <div className="card" style={{ width: '380px', height: '550px', display: 'flex', flexDirection: 'column', padding: 0, boxShadow: 'var(--shadow-lg)' }}>
          <div style={{ background: 'var(--accent-gradient)', color: 'white', padding: '1.25rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}><MessageCircle size={22} /><h3 style={{ fontSize: '1.1rem', marginBottom: 0, color: 'white' }}>Live Support</h3></div>
            <button onClick={() => setIsOpen(false)} style={{ background: 'none', border: 'none', color: 'white', cursor: 'pointer' }}><X size={22} /></button>
          </div>
          <div style={{ flex: 1, padding: '1.25rem', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '1.25rem', background: 'var(--bg-base)' }}>
            <div style={{ textAlign: 'center', margin: '0.5rem 0' }}><span className="badge" style={{ background: 'var(--bg-tertiary)', color: 'var(--text-secondary)' }}>Today</span></div>
            {chats.map((c, i) => (
              <div key={i} style={{ alignSelf: c.isBot ? 'flex-start' : 'flex-end', maxWidth: '85%' }}>
                <div style={{ padding: '0.85rem 1.15rem', borderRadius: c.isBot ? '0 1.25rem 1.25rem 1.25rem' : '1.25rem 0 1.25rem 1.25rem', background: c.isBot ? 'var(--bg-secondary)' : 'var(--accent-gradient)', color: c.isBot ? 'var(--text-primary)' : 'white', boxShadow: 'var(--shadow-sm)', fontSize: '0.95rem', lineHeight: 1.5 }}>
                  {c.text}
                </div>
              </div>
            ))}
          </div>
          <form onSubmit={handleSend} style={{ padding: '1.25rem', display: 'flex', gap: '0.75rem', background: 'var(--bg-secondary)', borderTop: '1px solid var(--border-color)' }}>
            <input type="text" placeholder="Type a message..." className="form-input" style={{ flex: 1, borderRadius: 'var(--radius-full)' }} value={msg} onChange={e => setMsg(e.target.value)} />
            <button type="submit" className="btn btn-primary" style={{ padding: '0.75rem', borderRadius: '50%', width: '45px', height: '45px' }}><Send size={20} /></button>
          </form>
        </div>
      )}
    </div>
  );
};
export default SupportChatWidget;
