import React, { useMemo } from 'react';
import { Users, FileCheck, Check, X } from 'lucide-react';
import { useReactTable, getCoreRowModel, flexRender, getSortedRowModel } from '@tanstack/react-table';

const mockPendingTasks = [
  { id: 'TSK-01', type: 'Policy Approval', user: 'Rahul K.', detail: 'Health Protect Plus - ₹5,00,000' },
  { id: 'TSK-02', type: 'Claim Verification', user: 'Anita S.', detail: 'Auto Insurance - CLM-2024-005' },
  { id: 'TSK-03', type: 'Document Verification', user: 'Vikram B.', detail: 'ID Proof & Address Proof' }
];

const AdminPanel = () => {
  const columns = useMemo(() => [
    { header: 'Task', accessorKey: 'type', cell: info => <span className={`badge ${info.getValue().includes('Claim') ? 'badge-pending' : 'badge-active'}`}>{info.getValue()}</span> },
    { header: 'User', accessorKey: 'user', cell: info => <span style={{ fontWeight: 500 }}>{info.getValue()}</span> },
    { header: 'Details', accessorKey: 'detail', cell: info => <span className="secondary-text">{info.getValue()}</span> },
    { header: 'Actions', id: 'actions', cell: () => (
      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
        <button className="btn" style={{ padding: '0.5rem', background: 'var(--status-active-bg)', color: 'var(--status-active-text)' }}><Check size={18} /></button>
        <button className="btn" style={{ padding: '0.5rem', background: 'var(--status-expired-bg)', color: 'var(--status-expired-text)' }}><X size={18} /></button>
      </div>
    )}
  ], []);

  const table = useReactTable({ data: mockPendingTasks, columns, getCoreRowModel: getCoreRowModel(), getSortedRowModel: getSortedRowModel() });

  return (
    <div>
      <div style={{ marginBottom: '2.5rem' }}><h2>Admin Control Panel</h2><p className="secondary-text">Manage users, approve policies, and verify claims.</p></div>
      <div className="grid-summary">
        <div className="card interactive" style={{ display: 'flex', alignItems: 'center', gap: '1.5rem', padding: '1.5rem' }}>
          <div style={{ padding: '1.25rem', borderRadius: 'var(--radius-lg)', background: 'var(--accent-secondary)' }}><Users size={28} color="var(--accent-primary)" /></div>
          <div><p className="secondary-text" style={{ fontWeight: 500 }}>Total Users</p><h2 style={{ marginBottom: 0, fontSize: '2rem' }}>1,248</h2></div>
        </div>
        <div className="card interactive" style={{ display: 'flex', alignItems: 'center', gap: '1.5rem', padding: '1.5rem' }}>
          <div style={{ padding: '1.25rem', borderRadius: 'var(--radius-lg)', background: 'var(--status-pending-bg)' }}><FileCheck size={28} color="var(--status-pending-text)" /></div>
          <div><p className="secondary-text" style={{ fontWeight: 500 }}>Pending</p><h2 style={{ marginBottom: 0, fontSize: '2rem' }}>24</h2></div>
        </div>
      </div>

      <div style={{ display: 'flex', gap: '2.5rem', flexWrap: 'wrap' }}>
        <div className="card" style={{ flex: '2 1 500px', padding: '2rem' }}>
          <h3 style={{ marginBottom: '2rem' }}>Action Items</h3>
          <div style={{ overflowX: 'auto' }}>
            <table style={{ margin: 0, width: '100%' }}>
              <thead>
                {table.getHeaderGroups().map(headerGroup => (
                  <tr key={headerGroup.id}>
                    {headerGroup.headers.map(header => (
                      <th key={header.id} style={{ textAlign: header.id === 'actions' ? 'right' : 'left' }}>
                        {flexRender(header.column.columnDef.header, header.getContext())}
                      </th>
                    ))}
                  </tr>
                ))}
              </thead>
              <tbody>
                {table.getRowModel().rows.map(row => (
                  <tr key={row.id}>
                    {row.getVisibleCells().map(cell => (
                      <td key={cell.id} style={{ textAlign: cell.column.id === 'actions' ? 'right' : 'left' }}>
                        {flexRender(cell.column.columnDef.cell, cell.getContext())}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
        <div className="card" style={{ flex: '1 1 300px', padding: '2rem' }}>
          <h3 style={{ marginBottom: '2rem' }}>Quick Actions</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            <button className="btn btn-outline" style={{ justifyContent: 'flex-start', padding: '1.25rem' }}>Generate Report</button>
            <button className="btn btn-outline" style={{ justifyContent: 'flex-start', padding: '1.25rem' }}>Update Rules</button>
          </div>
        </div>
      </div>
    </div>
  );
};
export default AdminPanel;
