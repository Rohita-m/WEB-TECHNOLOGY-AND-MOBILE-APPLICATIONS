import React, { useMemo } from 'react';
import { Download } from 'lucide-react';
import { useReactTable, getCoreRowModel, flexRender, getSortedRowModel, getPaginationRowModel } from '@tanstack/react-table';

const mockPayments = [
  { id: 'TXN-908123', date: '12 Oct 2024', description: 'Health Protect - Renewal', amount: 15000, status: 'Completed', method: 'Credit Card' },
  { id: 'TXN-908124', date: '05 Nov 2024', description: 'Auto Insurance - Initial', amount: 8500, status: 'Pending', method: 'UPI' },
  { id: 'TXN-907100', date: '12 Oct 2023', description: 'Health Protect - Initial', amount: 15000, status: 'Completed', method: 'Net Banking' },
  { id: 'TXN-907101', date: '12 Nov 2023', description: 'Term Life - Initial', amount: 24000, status: 'Completed', method: 'Debit Card' }
];

const PaymentHistory = () => {
  const columns = useMemo(() => [
    { header: 'Transaction ID', accessorKey: 'id', cell: info => <span style={{ fontWeight: 600 }}>{info.getValue()}</span> },
    { header: 'Date', accessorKey: 'date', cell: info => <span className="secondary-text">{info.getValue()}</span> },
    { header: 'Description', accessorKey: 'description' },
    { header: 'Method', accessorKey: 'method', cell: info => <span className="secondary-text">{info.getValue()}</span> },
    { header: 'Amount', accessorKey: 'amount', cell: info => <span style={{ fontWeight: 700 }}>₹{info.getValue().toLocaleString()}</span> },
    { header: 'Status', accessorKey: 'status', cell: info => <span className={`badge ${info.getValue() === 'Completed' ? 'badge-active' : 'badge-pending'}`}>{info.getValue()}</span> },
    { header: 'Action', id: 'actions', cell: () => <button className="btn btn-outline" style={{ padding: '0.4rem 0.8rem', fontSize: '0.8rem' }}>Invoice</button> }
  ], []);

  const table = useReactTable({
    data: mockPayments,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
    getPaginationRowModel: getPaginationRowModel()
  });

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2.5rem' }}>
        <h2>Payment History</h2>
        <button className="btn btn-outline"><Download size={18} /> Download Statement</button>
      </div>
      <div className="card" style={{ padding: '0', overflowX: 'auto' }}>
        <table style={{ margin: 0 }}>
          <thead>
            {table.getHeaderGroups().map(headerGroup => (
              <tr key={headerGroup.id}>
                {headerGroup.headers.map(header => (
                  <th key={header.id} onClick={header.column.getToggleSortingHandler()} style={{ cursor: header.column.getCanSort() ? 'pointer' : 'default' }}>
                    {flexRender(header.column.columnDef.header, header.getContext())}
                    {{ asc: ' 🔼', desc: ' 🔽' }[header.column.getIsSorted()] ?? null}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
            {table.getRowModel().rows.map(row => (
              <tr key={row.id}>
                {row.getVisibleCells().map(cell => (
                  <td key={cell.id}>{flexRender(cell.column.columnDef.cell, cell.getContext())}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {/* Pagination Controls - simplified */}
      <div style={{ display: 'flex', gap: '1rem', marginTop: '1rem', justifyContent: 'flex-end' }}>
        <button className="btn btn-outline" style={{ padding: '0.4rem 1rem' }} onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()}>Prev</button>
        <button className="btn btn-outline" style={{ padding: '0.4rem 1rem' }} onClick={() => table.nextPage()} disabled={!table.getCanNextPage()}>Next</button>
      </div>
    </div>
  );
};
export default PaymentHistory;
