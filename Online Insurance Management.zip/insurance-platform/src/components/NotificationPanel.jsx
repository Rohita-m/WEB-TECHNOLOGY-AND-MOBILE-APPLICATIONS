import React from 'react';
import { Info, CheckCircle, Clock } from 'lucide-react';

const NotificationPanel = () => {
  const notifs = [
    { id: 1, title: 'Renewal Reminder', msg: 'Health insurance renewal due in 5 days.', type: 'warning', time: '2h ago' },
    { id: 2, title: 'Claim Update', msg: 'Claim CLM-2024-001 is Under Review.', type: 'info', time: '1d ago' },
    { id: 3, title: 'Payment Successful', msg: 'Received ₹15,000 for POL-100234.', type: 'success', time: '3d ago' },
  ];
  const getIcon = (type) => {
    if(type==='warning') return <Clock size={20} color="var(--status-pending-text)" />;
    if(type==='info') return <Info size={20} color="var(--status-approved-text)" />;
    return <CheckCircle size={20} color="var(--status-active-text)" />;
  };

  return (
    <div className="card" style={{ width: '350px', padding: 0, boxShadow: 'var(--shadow-lg)' }}>
      <div style={{ padding: '1.25rem', borderBottom: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h3 style={{ fontSize: '1.1rem', marginBottom: 0 }}>Notifications</h3>
        <span className="badge badge-active">3 New</span>
      </div>
      <div style={{ maxHeight: '350px', overflowY: 'auto' }}>
        {notifs.map(n => (
          <div key={n.id} style={{ padding: '1.25rem', borderBottom: '1px solid var(--border-color)', display: 'flex', gap: '1rem', cursor: 'pointer', transition: 'background var(--transition-fast)' }} onMouseOver={e=>e.currentTarget.style.background='var(--bg-tertiary)'} onMouseOut={e=>e.currentTarget.style.background='transparent'}>
            <div style={{ marginTop: '0.2rem' }}>{getIcon(n.type)}</div>
            <div>
              <h4 style={{ fontSize: '0.95rem', marginBottom: '0.3rem' }}>{n.title}</h4>
              <p className="secondary-text" style={{ fontSize: '0.85rem', marginBottom: '0.4rem' }}>{n.msg}</p>
              <span className="secondary-text" style={{ fontSize: '0.75rem', fontWeight: 500 }}>{n.time}</span>
            </div>
          </div>
        ))}
      </div>
      <div style={{ padding: '1rem', textAlign: 'center', background: 'var(--bg-tertiary)', cursor: 'pointer', fontWeight: 600, color: 'var(--accent-primary)' }}>
        View All
      </div>
    </div>
  );
};
export default NotificationPanel;
