import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Calculator } from 'lucide-react';
import { toast } from 'sonner';

const calcSchema = z.object({
  policyType: z.string(),
  age: z.coerce.number().min(18, 'Must be at least 18').max(100, 'Invalid age'),
  coverageAmount: z.string(),
  duration: z.string(),
  healthConditions: z.boolean().optional(),
});

const PremiumCalculator = () => {
  const [estimatedPremium, setEstimatedPremium] = useState(null);

  const { register, handleSubmit, formState: { errors }, watch } = useForm({
    resolver: zodResolver(calcSchema),
    defaultValues: { policyType: 'health', age: '', coverageAmount: '500000', duration: '1', healthConditions: false }
  });

  const policyType = watch('policyType');

  const onSubmit = (data) => {
    let base = parseInt(data.coverageAmount) * 0.02; 
    if (data.policyType === 'life') base *= 0.5;
    if (data.policyType === 'auto') base *= 1.5;
    
    if (data.age > 45) base *= 1.4; 
    else if (data.age > 30) base *= 1.2;
    
    if (data.healthConditions && data.policyType !== 'auto') base *= 1.5;
    
    const duration = parseInt(data.duration);
    if (duration > 1) base *= (1 - (duration * 0.05)); 
    
    setEstimatedPremium(Math.round(base / 12));
    toast.success('Calculation Complete', { description: 'Estimated premium generated successfully.' });
  };

  return (
    <div>
      <h2 style={{ marginBottom: '2.5rem' }}>Premium Calculator</h2>
      <div style={{ display: 'flex', gap: '2.5rem', flexWrap: 'wrap' }}>
        <div className="card" style={{ flex: '1 1 450px' }}>
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="form-group">
              <label className="form-label">Policy Type</label>
              <select className="form-input" {...register('policyType')}>
                <option value="health">Health Insurance</option>
                <option value="life">Term Life Insurance</option>
                <option value="auto">Auto Insurance</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Age</label>
              <input type="number" className="form-input" placeholder="Enter age" style={{ borderColor: errors.age ? 'var(--status-expired-text)' : '' }} {...register('age')} />
              {errors.age && <p style={{ color: 'var(--status-expired-text)', fontSize: '0.8rem', marginTop: '0.25rem' }}>{errors.age.message}</p>}
            </div>
            <div className="form-group">
              <label className="form-label">Coverage Amount (₹)</label>
              <select className="form-input" {...register('coverageAmount')}>
                <option value="300000">₹3,00,000</option>
                <option value="500000">₹5,00,000</option>
                <option value="1000000">₹10,00,000</option>
                <option value="5000000">₹50,00,000</option>
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Duration</label>
              <select className="form-input" {...register('duration')}>
                <option value="1">1 Year</option>
                <option value="2">2 Years (10% Discount)</option>
                <option value="3">3 Years (15% Discount)</option>
              </select>
            </div>
            {policyType !== 'auto' && (
              <div className="form-group" style={{ flexDirection: 'row', alignItems: 'center' }}>
                <input type="checkbox" id="health" style={{ width: '1.2rem', height: '1.2rem' }} {...register('healthConditions')} />
                <label htmlFor="health" className="form-label" style={{ marginBottom: 0 }}>Pre-existing health conditions?</label>
              </div>
            )}
            <button type="submit" className="btn btn-primary" style={{ width: '100%', marginTop: '1.5rem' }}>
              <Calculator size={18} /> Calculate Estimate
            </button>
          </form>
        </div>
        
        <div style={{ flex: '1 1 350px' }}>
          <div className="card" style={{ height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', textAlign: 'center', background: 'var(--accent-gradient)' }}>
            <Calculator size={56} color="white" style={{ marginBottom: '1.5rem', opacity: 0.9 }} />
            <h3 style={{ color: 'white' }}>Estimated Premium</h3>
            <p style={{ color: 'rgba(255,255,255,0.8)', marginBottom: '2rem' }}>Results based on inputs</p>
            {estimatedPremium ? (
              <div style={{ animation: 'popIn 0.5s ease-out' }}>
                <h1 style={{ fontSize: '3.5rem', color: 'white', marginBottom: '0.5rem', WebkitTextFillColor: 'white' }}>₹{estimatedPremium.toLocaleString()}</h1>
                <p style={{ color: 'rgba(255,255,255,0.8)', fontWeight: 500 }}>per month</p>
                <p style={{ marginTop: '1.5rem', fontSize: '0.9rem', color: 'rgba(255,255,255,0.6)' }}>Annual: ₹{(estimatedPremium * 12).toLocaleString()}</p>
                <button className="btn" style={{ marginTop: '2.5rem', background: 'white', color: 'var(--accent-primary)' }}>Proceed to Buy</button>
              </div>
            ) : (
              <div style={{ padding: '2.5rem', border: '2px dashed rgba(255,255,255,0.3)', borderRadius: 'var(--radius-md)', width: '100%' }}>
                <p style={{ color: 'rgba(255,255,255,0.8)' }}>Fill form to see estimate</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
export default PremiumCalculator;
