import React, { useState } from 'react';
import PolicyCard from './PolicyCard';
import { Search } from 'lucide-react';

const mockPolicies = [
  { id: 1, policyNumber: 'POL-100234', type: 'Health Insurance', coverageAmount: 500000, premiumAmount: 12000, validFrom: '01 Jan 2024', validTo: '31 Dec 2024', status: 'Active' },
  { id: 2, policyNumber: 'POL-100456', type: 'Car Insurance', coverageAmount: 300000, premiumAmount: 8500, validFrom: '15 Mar 2024', validTo: '14 Mar 2025', status: 'Active' },
  { id: 3, policyNumber: 'POL-100789', type: 'Term Life Insurance', coverageAmount: 10000000, premiumAmount: 24000, validFrom: '01 Jun 2023', validTo: '31 May 2024', status: 'Expired' },
];

const PolicyList = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All');

  const filteredPolicies = mockPolicies.filter(policy => {
    return (policy.policyNumber.toLowerCase().includes(searchTerm.toLowerCase())) &&
           (filterType === 'All' || policy.type === filterType) &&
           (filterStatus === 'All' || policy.status === filterStatus);
  });

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2.5rem', flexWrap: 'wrap', gap: '1rem' }}>
        <h2>My Policies</h2>
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
          <div style={{ position: 'relative' }}>
            <Search size={18} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }} />
            <input type="text" placeholder="Search ID..." className="form-input" style={{ paddingLeft: '2.75rem', width: '200px' }} value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} />
          </div>
          <select className="form-input" style={{ width: '150px' }} value={filterType} onChange={(e) => setFilterType(e.target.value)}>
            <option value="All">All Types</option>
            <option value="Health Insurance">Health</option>
            <option value="Car Insurance">Auto</option>
            <option value="Term Life Insurance">Life</option>
          </select>
          <select className="form-input" style={{ width: '150px' }} value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}>
            <option value="All">All Statuses</option>
            <option value="Active">Active</option>
            <option value="Expired">Expired</option>
          </select>
        </div>
      </div>
      <div className="grid-cards">
        {filteredPolicies.map(p => <PolicyCard key={p.id} policy={p} />)}
      </div>
    </div>
  );
};
export default PolicyList;
