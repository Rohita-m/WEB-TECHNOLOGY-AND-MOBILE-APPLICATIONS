import React, { useState } from 'react';
import { Search, Bell, Moon, Sun, Menu } from 'lucide-react';
import NotificationPanel from './NotificationPanel';
import useStore from '../store/useStore';

const Navbar = ({ toggleSidebar }) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const { isDarkMode, toggleTheme, user } = useStore();

  return (
    <header style={{ 
      display: 'flex', alignItems: 'center', justifyContent: 'space-between', 
      padding: '1rem 2.5rem', background: 'var(--bg-primary)', backdropFilter: 'blur(12px)',
      borderBottom: '1px solid var(--border-color)', position: 'sticky', top: 0, zIndex: 40
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem' }}>
        <button className="btn btn-outline" onClick={toggleSidebar} style={{ padding: '0.5rem', borderRadius: '50%' }}>
          <Menu size={20} />
        </button>
        <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
          <Search size={18} style={{ position: 'absolute', left: '1rem', color: 'var(--text-tertiary)' }} />
          <input 
            type="text" placeholder="Search policies, claims..." 
            className="form-input" style={{ paddingLeft: '2.75rem', width: '350px', borderRadius: 'var(--radius-full)' }} 
          />
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem' }}>
        <button onClick={toggleTheme} className="btn btn-outline" style={{ padding: '0.6rem', borderRadius: '50%' }}>
          {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
        </button>
        
        <div style={{ position: 'relative' }}>
          <button onClick={() => setShowNotifications(!showNotifications)} className="btn btn-outline" style={{ padding: '0.6rem', borderRadius: '50%', position: 'relative' }}>
            <Bell size={20} />
            <span style={{ position: 'absolute', top: '2px', right: '4px', width: '10px', height: '10px', backgroundColor: 'var(--status-expired-text)', borderRadius: '50%', border: '2px solid var(--bg-secondary)' }}></span>
          </button>
          {showNotifications && <div style={{ position: 'absolute', top: '130%', right: '0', zIndex: 50 }}><NotificationPanel /></div>}
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', cursor: 'pointer', padding: '0.5rem', borderRadius: 'var(--radius-full)', background: 'var(--bg-tertiary)' }}>
          <img src={`https://api.dicebear.com/7.x/lorelei/svg?seed=${user?.name || 'User'}`} alt="User" style={{ width: '40px', height: '40px', borderRadius: '50%', background: 'var(--accent-secondary)' }} />
          <div style={{ display: 'flex', flexDirection: 'column', paddingRight: '1rem' }}>
            <span style={{ fontSize: '0.9rem', fontWeight: 600 }}>{user?.name || 'Loading...'}</span>
            <span style={{ fontSize: '0.75rem', color: 'var(--text-secondary)' }}>{user?.role || 'Member'}</span>
          </div>
        </div>
      </div>
    </header>
  );
};
export default Navbar;
