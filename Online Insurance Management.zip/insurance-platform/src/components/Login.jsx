import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { useForm as useRHForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { toast } from 'sonner';
import { Shield, Lock, Mail, Loader2 } from 'lucide-react';
import useStore from '../store/useStore';

const loginSchema = z.object({
  email: z.string().email('Please enter a valid email address'),
  password: z.string().min(6, 'Password must be at least 6 characters'),
});

const Login = () => {
  const [isLoading, setIsLoading] = useState(false);
  const login = useStore((state) => state.login);
  const navigate = useNavigate();

  const { register, handleSubmit, formState: { errors } } = useRHForm({
    resolver: zodResolver(loginSchema),
  });

  const onSubmit = (data) => {
    setIsLoading(true);
    // Mock API call
    setTimeout(() => {
      login({
        name: 'Rohita M',
        email: data.email,
        phone: '+91 98765 43210',
        address: '123 Tech Park, Bangalore',
        nomineeName: 'Karthik',
        nomineeRelation: 'Spouse',
        role: 'Premium Member'
      });
      toast.success('Successfully logged in!', { description: 'Welcome back to SureGuard.' });
      navigate('/dashboard');
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div style={{ height: '100vh', width: '100vw', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--bg-base)' }}>
      <div className="card" style={{ width: '100%', maxWidth: '420px', padding: '3rem 2.5rem', textAlign: 'center' }}>
        <div style={{ display: 'inline-flex', padding: '1.25rem', background: 'var(--accent-secondary)', borderRadius: '50%', marginBottom: '1.5rem' }}>
          <Shield size={40} color="var(--accent-primary)" />
        </div>
        <h2 style={{ marginBottom: '0.5rem' }}>Welcome to SureGuard</h2>
        <p className="secondary-text" style={{ marginBottom: '2.5rem' }}>Sign in to manage your portfolio</p>
        
        <form onSubmit={handleSubmit(onSubmit)} style={{ textAlign: 'left' }}>
          <div className="form-group" style={{ marginBottom: errors.email ? '0.5rem' : '1.25rem' }}>
            <label className="form-label">Email Address</label>
            <div style={{ position: 'relative' }}>
              <Mail size={18} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }} />
              <input type="email" placeholder="you@example.com" className="form-input" style={{ paddingLeft: '2.75rem', width: '100%', borderColor: errors.email ? 'var(--status-expired-text)' : '' }} {...register('email')} />
            </div>
            {errors.email && <p style={{ color: 'var(--status-expired-text)', fontSize: '0.8rem', marginTop: '0.25rem' }}>{errors.email.message}</p>}
          </div>
          
          <div className="form-group" style={{ marginBottom: '2.5rem' }}>
            <label className="form-label">Password</label>
            <div style={{ position: 'relative' }}>
              <Lock size={18} style={{ position: 'absolute', left: '1rem', top: '50%', transform: 'translateY(-50%)', color: 'var(--text-tertiary)' }} />
              <input type="password" placeholder="••••••••" className="form-input" style={{ paddingLeft: '2.75rem', width: '100%', borderColor: errors.password ? 'var(--status-expired-text)' : '' }} {...register('password')} />
            </div>
            {errors.password && <p style={{ color: 'var(--status-expired-text)', fontSize: '0.8rem', marginTop: '0.25rem' }}>{errors.password.message}</p>}
          </div>
          
          <button type="submit" className="btn btn-primary" style={{ width: '100%', padding: '0.85rem' }} disabled={isLoading}>
            {isLoading ? <Loader2 size={18} className="animate-spin" style={{ animation: 'spin 1s linear infinite' }} /> : 'Sign In securely'}
          </button>
        </form>
        <p className="secondary-text" style={{ marginTop: '2rem', fontSize: '0.85rem' }}>For demo, any valid email/password works.</p>
      </div>
    </div>
  );
};
export default Login;
