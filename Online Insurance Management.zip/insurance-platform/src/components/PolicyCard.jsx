import React from 'react';
import { ShieldAlert, FileText, Calendar, IndianRupee } from 'lucide-react';

const PolicyCard = ({ policy }) => {
  const getStatusBadge = (status) => {
    switch(status.toLowerCase()) {
      case 'active': return <span className="badge badge-active">Active</span>;
      case 'expired': return <span className="badge badge-expired">Expired</span>;
      case 'pending': return <span className="badge badge-pending">Pending</span>;
      default: return <span className="badge">{status}</span>;
    }
  };

  return (
    <div className="card interactive" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
          <div style={{ padding: '1rem', background: 'var(--accent-secondary)', borderRadius: 'var(--radius-md)' }}>
            <ShieldAlert size={24} color="var(--accent-primary)" />
          </div>
          <div>
            <h3 style={{ fontSize: '1.25rem' }}>{policy.type}</h3>
            <span className="policy-number">{policy.policyNumber}</span>
          </div>
        </div>
        {getStatusBadge(policy.status)}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.5rem', padding: '1.5rem 0', borderTop: '1px solid var(--border-color)', borderBottom: '1px solid var(--border-color)' }}>
        <div>
          <p className="secondary-text" style={{ fontSize: '0.8rem', display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.25rem' }}>
            <FileText size={14} /> Coverage
          </p>
          <p style={{ fontWeight: 700, fontSize: '1.1rem' }}>₹{policy.coverageAmount.toLocaleString()}</p>
        </div>
        <div>
          <p className="secondary-text" style={{ fontSize: '0.8rem', display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.25rem' }}>
            <IndianRupee size={14} /> Premium
          </p>
          <p style={{ fontWeight: 700, fontSize: '1.1rem' }}>₹{policy.premiumAmount.toLocaleString()}</p>
        </div>
        <div style={{ gridColumn: '1 / -1' }}>
          <p className="secondary-text" style={{ fontSize: '0.8rem', display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.25rem' }}>
            <Calendar size={14} /> Validity
          </p>
          <p style={{ fontWeight: 500, fontSize: '0.9rem' }}>{policy.validFrom} to {policy.validTo}</p>
        </div>
      </div>

      <div style={{ display: 'flex', gap: '1rem', marginTop: 'auto' }}>
        <button className="btn btn-outline" style={{ flex: 1 }}>Details</button>
        {policy.status.toLowerCase() !== 'active' && (
          <button className="btn btn-primary" style={{ flex: 1 }}>Renew</button>
        )}
      </div>
    </div>
  );
};
export default PolicyCard;
