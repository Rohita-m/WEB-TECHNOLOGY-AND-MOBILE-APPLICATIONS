import React from 'react';
import { Shield, Activity, CheckCircle, IndianRupee } from 'lucide-react';
import AnalyticsDashboard from './AnalyticsDashboard';

const DashboardOverview = () => {
  const metrics = [
    { title: 'Active Policies', value: '4', icon: <Shield size={28} color="white" />, bg: 'var(--accent-gradient)' },
    { title: 'Pending Claims', value: '2', icon: <Activity size={28} color="var(--status-pending-text)" />, bg: 'var(--status-pending-bg)' },
    { title: 'Approved Claims', value: '18', icon: <CheckCircle size={28} color="var(--status-active-text)" />, bg: 'var(--status-active-bg)' },
    { title: 'Premium Paid', value: '₹45K', icon: <IndianRupee size={28} color="var(--status-approved-text)" />, bg: 'var(--status-approved-bg)' }
  ];

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2.5rem' }}>
        <div>
          <h1>Welcome back, Rohita M! 👋</h1>
          <p className="secondary-text">Here is your insurance portfolio at a glance.</p>
        </div>
        <button className="btn btn-primary">Download Report</button>
      </div>

      <div className="grid-summary">
        {metrics.map((metric, idx) => (
          <div key={idx} className="card interactive summary-card" style={{ display: 'flex', alignItems: 'center', gap: '1.5rem', padding: '1.5rem' }}>
            <div style={{ padding: '1.25rem', borderRadius: 'var(--radius-lg)', background: metric.bg, display: 'flex' }}>
              {metric.icon}
            </div>
            <div>
              <p className="secondary-text" style={{ fontWeight: 500 }}>{metric.title}</p>
              <h2 style={{ marginBottom: 0, fontSize: '2rem', marginTop: '0.25rem' }}>{metric.value}</h2>
            </div>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', gap: '2.5rem', flexWrap: 'wrap' }}>
        <div style={{ flex: '1 1 600px' }}>
          <AnalyticsDashboard />
        </div>
        
        <div style={{ flex: '1 1 350px' }}>
          <div className="card">
            <h3 style={{ marginBottom: '1.5rem' }}>Upcoming Renewals</h3>
            
            <div style={{ padding: '1.25rem', border: '1.5px solid var(--border-highlight)', borderRadius: 'var(--radius-md)', background: 'var(--accent-secondary)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                <div>
                  <h4 style={{ fontSize: '1rem', fontWeight: 700 }}>Health Protect Plus</h4>
                  <p className="secondary-text" style={{ fontSize: '0.8rem' }}>POL-982347</p>
                </div>
                <span className="badge badge-pending">Due in 5 days</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
                <p style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--accent-primary)' }}>₹1,250</p>
                <button className="btn btn-primary" style={{ padding: '0.5rem 1rem' }}>Pay Now</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardOverview;
