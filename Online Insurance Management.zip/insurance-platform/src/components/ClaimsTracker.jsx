import React from 'react';
import ClaimStatusCard from './ClaimStatusCard';

const mockClaims = [
  { id: 'CLM-2024-001', type: 'Health', currentStatus: 'Under Review', statusDescription: 'Medical documents are currently being evaluated.', amount: 45000 },
  { id: 'CLM-2024-002', type: 'Auto', currentStatus: 'Payment Released', statusDescription: 'Payment successfully transferred to your bank.', amount: 15000 },
  { id: 'CLM-2023-089', type: 'Health', currentStatus: 'Rejected', statusDescription: 'Pre-existing conditions not covered in terms.', amount: 120000 }
];

const ClaimsTracker = () => {
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2.5rem' }}>
        <h2>Claims Tracker</h2>
        <button className="btn btn-primary">File New Claim</button>
      </div>
      <div className="grid-cards">
        {mockClaims.map(claim => <ClaimStatusCard key={claim.id} claim={claim} />)}
      </div>
    </div>
  );
};
export default ClaimsTracker;
