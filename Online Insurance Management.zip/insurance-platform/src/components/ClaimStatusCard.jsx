import React from 'react';
import { Clock, CheckCircle2, FileCheck, IndianRupee } from 'lucide-react';

const ClaimStatusCard = ({ claim }) => {
  const steps = [
    { label: 'Submitted', icon: <FileCheck size={16} /> },
    { label: 'Verified', icon: <CheckCircle2 size={16} /> },
    { label: 'Under Review', icon: <Clock size={16} /> },
    { label: 'Approved', icon: <CheckCircle2 size={16} /> },
    { label: 'Payment Released', icon: <IndianRupee size={16} /> }
  ];

  const currentStepIndex = steps.findIndex(step => step.label === claim.currentStatus);
  const isRejected = claim.currentStatus === 'Rejected';

  return (
    <div className="card interactive">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '2rem' }}>
        <div>
          <h3 style={{ fontSize: '1.25rem' }}>{claim.type} Claim</h3>
          <p className="policy-number" style={{ color: 'var(--text-secondary)' }}>{claim.id}</p>
        </div>
        <span className={`badge ${isRejected ? 'badge-rejected' : claim.currentStatus === 'Payment Released' ? 'badge-active' : 'badge-pending'}`}>
          {claim.currentStatus}
        </span>
      </div>

      <div className="timeline">
        {steps.map((step, idx) => {
          let dotClass = 'timeline-dot';
          if (isRejected && idx > 1) { if (idx === 2) dotClass += ' completed badge-rejected'; } 
          else { if (idx < currentStepIndex) dotClass += ' completed'; else if (idx === currentStepIndex) dotClass += ' current'; }
          const displayLabel = isRejected && idx === 2 ? 'Rejected' : step.label;

          return (
            <div key={idx} className="timeline-item">
              <div className={dotClass}></div>
              <div>
                <p style={{ fontWeight: idx <= currentStepIndex || (isRejected && idx === 2) ? 600 : 500, color: idx <= currentStepIndex || (isRejected && idx === 2) ? 'var(--text-primary)' : 'var(--text-tertiary)' }}>
                  {displayLabel}
                </p>
                {idx === currentStepIndex && !isRejected && <p className="secondary-text" style={{ fontSize: '0.8rem', marginTop: '0.3rem' }}>{claim.statusDescription}</p>}
                {isRejected && idx === 2 && <p className="secondary-text" style={{ fontSize: '0.8rem', marginTop: '0.3rem', color: 'var(--status-expired-text)' }}>{claim.statusDescription}</p>}
              </div>
            </div>
          );
        })}
      </div>
      
      <div style={{ marginTop: '1.5rem', paddingTop: '1.5rem', borderTop: '1px solid var(--border-color)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <p className="secondary-text" style={{ fontSize: '0.8rem', marginBottom: '0.2rem' }}>Claim Amount</p>
          <p style={{ fontWeight: 700, fontSize: '1.2rem' }}>₹{claim.amount.toLocaleString()}</p>
        </div>
        <button className="btn btn-outline" style={{ padding: '0.5rem 1rem' }}>Documents</button>
      </div>
    </div>
  );
};
export default ClaimStatusCard;
