import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import useStore from '../store/useStore';

const data = [
  { name: 'Jan', revenue: 120000, claims: 24000 },
  { name: 'Feb', revenue: 150000, claims: 35000 },
  { name: 'Mar', revenue: 110000, claims: 18000 },
  { name: 'Apr', revenue: 180000, claims: 42000 },
  { name: 'May', revenue: 220000, claims: 38000 },
  { name: 'Jun', revenue: 200000, claims: 30000 },
];

const AnalyticsDashboard = () => {
  const [chartType, setChartType] = useState('bar');
  const isDarkMode = useStore((state) => state.isDarkMode);
  
  const textColor = isDarkMode ? '#94a3b8' : '#64748b';
  const gridColor = isDarkMode ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)';

  return (
    <div className="card" style={{ height: '100%', minHeight: '400px', display: 'flex', flexDirection: 'column', padding: '2rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1.5rem' }}>
        <h3>Portfolio Performance</h3>
        <div style={{ display: 'flex', gap: '1rem' }}>
          <select className="form-input" style={{ width: 'auto', padding: '0.4rem 1rem' }} value={chartType} onChange={(e) => setChartType(e.target.value)}>
            <option value="bar">Bar Chart</option>
            <option value="area">Area Chart</option>
          </select>
          <select className="form-input" style={{ width: 'auto', padding: '0.4rem 1rem' }}>
            <option>Last 6 Months</option>
          </select>
        </div>
      </div>
      
      <div style={{ flex: 1, minHeight: '250px', width: '100%' }}>
        <ResponsiveContainer width="100%" height="100%">
          {chartType === 'bar' ? (
            <BarChart data={data} margin={{ top: 20, right: 0, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={gridColor} />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: textColor, fontSize: 12 }} dy={10} />
              <YAxis axisLine={false} tickLine={false} tick={{ fill: textColor, fontSize: 12 }} tickFormatter={(val) => `₹${val/1000}k`} />
              <Tooltip 
                cursor={{ fill: isDarkMode ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.05)' }} 
                contentStyle={{ borderRadius: '12px', background: isDarkMode ? '#1e293b' : '#fff', border: 'none', boxShadow: '0 10px 25px rgba(0,0,0,0.1)' }}
              />
              <Bar dataKey="revenue" name="Revenue" fill="#4f46e5" radius={[4, 4, 0, 0]} />
              <Bar dataKey="claims" name="Claims Payout" fill="#f59e0b" radius={[4, 4, 0, 0]} />
            </BarChart>
          ) : (
            <AreaChart data={data} margin={{ top: 20, right: 0, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.8}/>
                  <stop offset="95%" stopColor="#4f46e5" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke={gridColor} />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fill: textColor, fontSize: 12 }} dy={10} />
              <YAxis axisLine={false} tickLine={false} tick={{ fill: textColor, fontSize: 12 }} tickFormatter={(val) => `₹${val/1000}k`} />
              <Tooltip contentStyle={{ borderRadius: '12px', background: isDarkMode ? '#1e293b' : '#fff', border: 'none', boxShadow: '0 10px 25px rgba(0,0,0,0.1)' }} />
              <Area type="monotone" dataKey="revenue" name="Revenue" stroke="#4f46e5" strokeWidth={3} fillOpacity={1} fill="url(#colorRev)" />
            </AreaChart>
          )}
        </ResponsiveContainer>
      </div>
      
      <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: '2rem', paddingTop: '1.5rem', borderTop: '1px solid var(--border-color)' }}>
        <div style={{ textAlign: 'center' }}>
          <p className="secondary-text" style={{ fontSize: '0.9rem', marginBottom: '0.5rem' }}>Total Growth</p>
          <p style={{ fontWeight: 700, fontSize: '1.5rem', color: 'var(--status-active-text)' }}>+14.5%</p>
        </div>
        <div style={{ textAlign: 'center' }}>
          <p className="secondary-text" style={{ fontSize: '0.9rem', marginBottom: '0.5rem' }}>Claims Ratio</p>
          <p style={{ fontWeight: 700, fontSize: '1.5rem' }}>24%</p>
        </div>
      </div>
    </div>
  );
};
export default AnalyticsDashboard;
