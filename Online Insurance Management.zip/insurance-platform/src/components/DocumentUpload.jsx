import React, { useState } from 'react';
import { UploadCloud, File, X, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

const DocumentUpload = () => {
  const [dragActive, setDragActive] = useState(false);
  const [files, setFiles] = useState([{ name: 'Aadhar_Card_Front.pdf', size: '2.4 MB', status: 'verified' }]);

  const handleDrag = (e) => { e.preventDefault(); e.stopPropagation(); setDragActive(e.type === "dragenter" || e.type === "dragover"); };
  const handleDrop = (e) => {
    e.preventDefault(); e.stopPropagation(); setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const f = e.dataTransfer.files[0];
      if (f.size > 10 * 1024 * 1024) { toast.error('File too large', { description: 'Max file size is 10MB.' }); return; }
      
      const newFile = { name: f.name, size: (f.size / (1024*1024)).toFixed(1)+' MB', status: 'uploading' };
      setFiles([...files, newFile]);
      
      setTimeout(() => {
        setFiles(prev => prev.map(file => file.name === newFile.name ? { ...file, status: 'uploaded' } : file));
        toast.success('Document Uploaded', { description: `${f.name} uploaded successfully.` });
      }, 2000);
    }
  };

  return (
    <div style={{ maxWidth: '850px', margin: '0 auto' }}>
      <div style={{ marginBottom: '2.5rem' }}><h2>Document Upload</h2><p className="secondary-text">Upload your KYC securely.</p></div>
      <div className="card" style={{ border: `2.5px dashed ${dragActive ? 'var(--accent-primary)' : 'var(--border-color)'}`, background: dragActive ? 'var(--accent-secondary)' : 'var(--bg-secondary)', textAlign: 'center', padding: '5rem 2rem', marginBottom: '3rem' }} onDragEnter={handleDrag} onDragLeave={handleDrag} onDragOver={handleDrag} onDrop={handleDrop}>
        <UploadCloud size={64} color="var(--accent-primary)" style={{ marginBottom: '1.5rem' }} />
        <h2 style={{ marginBottom: '0.75rem' }}>Drag & Drop files here</h2>
        <p className="secondary-text" style={{ marginBottom: '2rem' }}>Supports PDF, JPG, PNG (Max 10MB)</p>
        <input type="file" id="file" style={{ display: 'none' }} onChange={e => {
          if(e.target.files[0]){
            const f = e.target.files[0];
            if (f.size > 10 * 1024 * 1024) { toast.error('File too large', { description: 'Max file size is 10MB.' }); return; }
            const newFile = { name: f.name, size: (f.size / (1024*1024)).toFixed(1)+' MB', status: 'uploading' };
            setFiles([...files, newFile]);
            setTimeout(() => {
              setFiles(prev => prev.map(file => file.name === newFile.name ? { ...file, status: 'uploaded' } : file));
              toast.success('Document Uploaded', { description: `${f.name} uploaded successfully.` });
            }, 2000);
          }
        }}/>
        <label htmlFor="file" className="btn btn-primary" style={{ cursor: 'pointer', padding: '0.8rem 2rem' }}>Browse Files</label>
      </div>
      <h3 style={{ marginBottom: '1.5rem' }}>Uploaded Documents</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
        {files.map((f, i) => (
          <div key={i} className="card" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1.25rem 1.5rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '1.25rem' }}>
              <div style={{ padding: '1rem', background: 'var(--bg-tertiary)', borderRadius: 'var(--radius-md)' }}><File size={24} color="var(--text-secondary)" /></div>
              <div>
                <p style={{ fontWeight: 600, fontSize: '1.05rem', marginBottom: '0.3rem' }}>{f.name}</p>
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                  <p className="secondary-text" style={{ fontSize: '0.85rem' }}>{f.size}</p>
                  {f.status === 'verified' && <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', fontSize: '0.85rem', color: 'var(--status-active-text)' }}><CheckCircle size={14} /> Verified</span>}
                </div>
              </div>
            </div>
            {f.status === 'uploading' ? <div style={{ width: '120px' }}><div className="progress-container"><div className="progress-bar" style={{ width: '60%', animation: 'pulse 1s infinite' }}></div></div></div> : <button onClick={() => { setFiles(files.filter(x => x.name !== f.name)); toast('File Removed'); }} className="btn btn-outline" style={{ padding: '0.6rem', border: 'none', color: 'var(--status-expired-text)' }}><X size={20} /></button>}
          </div>
        ))}
      </div>
    </div>
  );
};
export default DocumentUpload;
