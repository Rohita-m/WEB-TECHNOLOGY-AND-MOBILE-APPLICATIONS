export const fetchWithRetry = async (url, options = {}, retries = 3, backoff = 300) => {
  const BASE_URL = 'https://api.sureguard-insurance.com/v1';
  try {
    const response = await fetch(`${BASE_URL}${url}`, {
      ...options,
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${localStorage.getItem('token')}`, ...options.headers },
    });
    if (!response.ok) {
      if (response.status === 401) { localStorage.removeItem('token'); window.location.href = '/login'; throw new Error('Session expired'); }
      throw new Error(`API error: ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    if (retries > 0) {
      await new Promise((res) => setTimeout(res, backoff));
      return fetchWithRetry(url, options, retries - 1, backoff * 2);
    }
    throw error;
  }
};
